package itc;
import robocode.*;
import java.awt.Color;
import java.awt.geom.*; //for Point2D
import robocode.util.Utils;

//Pink1 - is robot by Evgenii Salnikov, Artemiy Maslov and Ihor Antonov

public class BlackPink1 extends Robot
{	
	double SentryX, SentryY = 0;
	
	public double normalRelativeAngle(double aAngle) 
	{ 
        if (aAngle > -180 && aAngle <= 180) 
            return aAngle; 
        
        double fixedAngle = aAngle; 
        
        while (fixedAngle <= -180) 
            fixedAngle += 360;
        
        while (fixedAngle > 180) 
        	fixedAngle -= 360; 
        
        return fixedAngle; 
    }
	
	public void goTo(Point2D target)
	{
        Point2D myLoc = new Point2D.Double(getX(), getY());
        double X = myLoc.getX();
        double Y = myLoc.getY();
        
        double distance = myLoc.distance(target);
        double trgX = target.getX();
        double trgY = target.getY();
        
        double turnAngle = 0;
        if((trgY - Y) < 0)
            turnAngle = -180;
        
        double extraAngle = Math.toDegrees(Math.atan((trgX - X) / (trgY - Y)));
        turnAngle = normalRelativeAngle(turnAngle - getHeading() + extraAngle);
        
        turnRight(turnAngle);
        ahead(distance);
    }
	
	public void run() 
	{
		setBodyColor(Color.BLACK);
		setGunColor(Color.PINK);
		
		goTo(new Point2D.Double (400, 400));
		//turnGunRight(360);
		while(true) 
		{
			turnGunRight(360);
		
			ahead((Math.random() * 300) + 100);
			back((Math.random() * 300) + 100);
			turnRight(90);
			turnGunRight(270);
			
			/*if(SentryX != 0 && SentryY != 0)
				goTo(new Point2D.Double(800 - SentryX, 800 - SentryY));*/
			if(getX() > 600 || getX() < 300 || getY() > 600 || getY() < 300)
				goTo(new Point2D.Double(400, 400));
		}
	}
	
	private double sin(double x) {
		return Math.cos(x);
	}
	
	private double cos(double x) {
		return Math.sin(x);
	}
	
	private double aimWithLinearPrediction(ScannedRobotEvent e, double shotStr) {
		double bulletSpeed = bulletSpeedFromEnergy(shotStr);
		double enVel = e.getVelocity();
		double enHeaRad = degToRad(e.getHeading());
		double abBeaRad = degToRad(getHeading() + e.getBearing());
		double d = e.getDistance();
		double x0 = cos(abBeaRad) * d, y0 = sin(abBeaRad) * d, vx = enVel * cos(enHeaRad), vy = enVel * sin(enHeaRad);
		//find possible collision time
		double t;
		for (t = 0; t * bulletSpeed < (Math.sqrt((x0 + vx*t) + (y0 + vy * t)) / bulletSpeed); t++);
		
		//find possible collision point
		double colX = x0 + vx * t;
		double colY = y0 + vy * t;
		
		//turn towards collision point and shoot
		double shangleRad = Math.atan2(colX, colY);
		double shangleDeg = radToDeg(shangleRad);
		double shrot = shangleDeg - getGunHeading();
		shrot = Utils.normalRelativeAngleDegrees(shrot);
		turnGunRight(shrot);
		return shrot;
	}
	
	private double bulletSpeedFromEnergy(double energy) 
	{
		return 20 - 3 * energy;
	}

	private double degToRad(double deg) 
	{
		return deg / 180.0 * Math.PI;
	}
	
	private double radToDeg(double rad) 
	{
		return rad / Math.PI * 180.0;
	}

	public void onScannedRobot(ScannedRobotEvent e) 
	{
		if(!e.isSentryRobot())
		{
			//double gunTurn = getHeading() + e.getBearing() - getRadarHeading();
			//double shootAhead = getHeading() + e.getBearing() - getRadarHeading() + Math.asin(e.getVelocity()/11.0) * 52;
			//turnGunRight(normalRelativeAngle(gunTurn));
			aimWithLinearPrediction(e, 3);
			
			fire(3);
		}
		else 
		{
			double angle1 = Math.toRadians((getHeading() + e.getBearing()) % 360);
			
	 		SentryX = (getX() + Math.sin(angle1) * e.getDistance());
	 		SentryY = (getY() + Math.cos(angle1) * e.getDistance());
			
			out.println("Sentry X: " + SentryX);
			out.println("Sentry Y: " + SentryY);
			turnGunRight(30);
		}
	}
}
